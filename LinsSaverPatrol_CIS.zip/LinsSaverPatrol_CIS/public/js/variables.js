const SERVER = window.location.origin;
