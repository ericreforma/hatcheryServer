<div class="topbar">
    <div class="logo_container">
        <img src="<?php echo e(asset('/img/logo_big.jpg')); ?>" />
        <h1>Saver Patrol</h1>
    </div>
    <div class="menu_button_container">
        <div>
            <button class="btn btn-light menu_button">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </div>
    <div class="account_container dropdown">

        <div class="profile_picture dropdown-toggle" id="accountMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo e(substr(Auth::user()->username, 0, 1)); ?>

        </div>
        <div class="dropdown-menu account_menu" aria-labelledby="dropdownMenuButton">
            <div class="account_profile">
                <div class="profile_picture">
                    <?php echo e(substr(Auth::user()->username, 0, 1)); ?>

                </div>
                <div class="profile_name">
                    <h5><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></h5>
                    <h6><?php echo e(Auth::user()->email); ?> </h6>
                </div>
            </div>

            <div class="dropdown-divider"></div>

            <a class="dropdown-item" href="#">
                <i class="fas fa-cog"></i><span>Account Settings</span>
            </a>

            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i><span>Logout</span>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </a>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/master/topbar.blade.php ENDPATH**/ ?>