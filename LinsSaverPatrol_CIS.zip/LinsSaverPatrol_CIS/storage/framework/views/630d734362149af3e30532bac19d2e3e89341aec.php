<?php $fullname = $user->firstname . ' ' . $user->middlename . ' ' . $user->lastname ?>
<?php $__env->startSection('title',$fullname); ?>
<?php $__env->startSection('container'); ?>

    <div class="user_details block_container">
        <div class="container-fluid">
            <div class="row">
                <input type="hidden" name='user_id' id="user_id" value="<?php echo e($user->id); ?>" />
                <!-- PROFILE -->
                    <div class=" col-12">
                        <h2>Profile</h2>
                        <hr />
                        <table class="user_details_table">
                           <tr>
                               <td>Name</td>
                               <td><?php echo e($fullname); ?> </td>
                           </tr> 
                           <tr>
                               <td>Username</td>
                               <td><?php echo e($user->username); ?> </td>
                           </tr> 
                           <tr>
                               <td>Account Type</td>
                               <td>
                                    <h5>
                                        <span class="badge badge-<?php echo e($user->type_id == 1 ? 'primary' : 'warning'); ?>">
                                            <?php echo e($user->type->description); ?>

                                        </span>
                                    </h5>
                               </td>
                           </tr> 
                           <tr>
                               <td>Contact Number</td>
                               <td><?php echo e($user->contact_number); ?> </td>
                           </tr> 
                           <tr>
                               <td>Email</td>
                               <td><?php echo e($user->email); ?> </td>
                           </tr> 
                        </table>
                    </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <!-- ACCOUNT PRIVILEGES -->
                    <h2>Privileges</h2>
                    <table class="table table-hover table_priv">
                        <tr>
                            <td></td>
                            <td>VIEW</td>
                            <td>ADD</td>
                            <td>EDIT</td>
                            <td>DELETE</td>
                        </tr>
                        <tbody>
                            <?php $__currentLoopData = $user->privileges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($priv->feature_description); ?></td>
                                <td>
                                    <?php if($priv->role_view == 1): ?>
                                        <i class="fas fa-check"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($priv->role_add == 1): ?>
                                        <i class="fas fa-check"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($priv->role_edit == 1): ?>
                                        <i class="fas fa-check"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($priv->role_delete == 1): ?>
                                        <i class="fas fa-check"></i>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    
                </div>
            </div>
            <div class="row justify-content-end mt-4">
                <?php if(Auth::user()->usermanagement_role->role_edit == 1): ?>
                    <div class="col-12 col-sm-4 col-md-3 col-lg-2">
                        <a href="<?php echo e(route('users_edit', ['id' => $user->id] )); ?>" class="btn btn-primary btn-block">Edit</a>
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->usermanagement_role->role_delete == 1): ?>
                    <div class="col-12 col-sm-4 col-md-3 col-lg-2">
                        <div class="btn btn-danger btn-block btn_delete">Delete</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="delete_modallabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete_modallabel">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to <strong>REMOVE</strong> user<br> <strong><?php echo e($fullname); ?>?</strong><br><br>
                    We will still keep their records but this user will be permanently unavailable.
                </div>
                <div class="modal-footer">
                    <div class="container-fluid">
                        <div class="row justify-content-between">
                            <div class="col-4 col-sm-3 col-md-2 col-lg-2">
                                <button type="button" class="btn btn-link btn_yes_delete">Yes</button>
                            </div>
                            <div class="col-4 col-sm-3 col-md-2 col-lg-2">
                                <button type="button" class="btn btn-danger btn_no_delete">NO</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            $('.btn_delete').on('click', function(){
                $('#delete_modal').modal('show');
            });
            $('.btn_yes_delete').on('click', function(){
                $('.btn_yes_delete').attr('disabled','disabled');
                $('.btn_yes_delete').html(`<div class="spinner-border text-dark spinner-border-sm" role="status">
                    <span class="sr-only">Loading...</span>
                </div>`);

                $.ajax({
                    type: 'POST',
                    url: `${window.location.origin}/influencer/LinsSaverPatrol_CIS/public/api/userManagement/delete`,
                    data: {
                        id: $('#user_id').val(),
                    },
                    success: function(response){
                        window.location.replace(`${window.location.origin}/influencer/LinsSaverPatrol_CIS/public/users/list`);
                    }

                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\influencer\LinsSaverPatrol_CIS\resources\views/user/details.blade.php ENDPATH**/ ?>