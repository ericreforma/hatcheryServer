<?php $__env->startSection('title',  'Reports'); ?>
<?php $__env->startSection('container'); ?>

    <div class="report_container container-fluid block_container">
        <div class="row">
            <div class=" col-md-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-city-tab" data-toggle="tab" href="#nav-city" role="tab" aria-controls="nav-city" aria-selected="true">SALES BY CITY</a>
                        <a class="nav-item nav-link" id="nav-barangay-tab" data-toggle="tab" href="#nav-barangay" role="tab" aria-controls="nav-barangay" aria-selected="false">SALES BY BARANGAY</a>
                        <a class="nav-item nav-link" id="nav-agent-tab" data-toggle="tab" href="#nav-agent" role="tab" aria-controls="nav-agent" aria-selected="false">SALES BY AGENT</a>
                        <a class="nav-item nav-link" id="nav-debit-tab" data-toggle="tab" href="#nav-debit" role="tab" aria-controls="nav-debit" aria-selected="false">SALES BY DEBIT AMOUNT/CONSIGNMENT</a>
                    </div>
                </nav>

                <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-city" role="tabpanel" aria-labelledby="nav-city-tab">
                            <h3>Sales by City</h3>
                            <div class="row justify-content-between">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">REPORT BY DATE</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Select date range" id="daterange_city">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                                    <div class="input-group mb-3">
                                        <button class='btn btn-success btn-block btn_show_city'>Show All Records</button>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-primary alert_city" role="alert">
                                Showing all records.
                            </div>
                            <table class="table table-hover table-striped table_city_report">
                                <thead>
                                    <tr>
                                        <th>Province</th>
                                        <th>City</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="nav-barangay" role="tabpanel" aria-labelledby="nav-barangay-tab">
                            <h3>Sales by Barangay</h3>
                            <div class="row justify-content-between">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">REPORT BY DATE</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Select date range" id="daterange_barangay">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                                    <div class="input-group mb-3">
                                        <button class='btn btn-success btn-block btn_show_barangay'>Show All Records</button>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-primary alert_barangay" role="alert">
                                Showing all records.
                            </div>
                            <table class="table table-hover table-striped table_barangay_report">
                                <thead>
                                    <tr>
                                        <th>Province</th>
                                        <th>City</th>
                                        <th>Barangay</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
                                </tbody>
                            </table>
                        </div>

                        <div class="tab-pane fade" id="nav-agent" role="tabpanel" aria-labelledby="nav-agent-tab">
                            <h3>Sales by Agent</h3>
                            <div class="row justify-content-between">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">REPORT BY DATE</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Select date range" id="daterange_customer">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                                    <div class="input-group mb-3">
                                        <button class='btn btn-success btn-block btn_show_customer'>Show All Records</button>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-primary alert_customer" role="alert">
                                Showing all records.
                            </div>
                            <table class="table table-hover table-striped table_agent_report">
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
                                </tbody>
                            </table>
                        </div>

                         <div class="tab-pane fade" id="nav-debit" role="tabpanel" aria-labelledby="nav-debit-tab">
                            <h3>Sales by Debit / Consignment</h3>
                            <div class="row justify-content-between">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">REPORT BY DATE</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Select date range" id="daterange_debit">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3">
                                    <div class="input-group mb-3">
                                        <button class='btn btn-success btn-block btn_show_debit'>Show All Records</button>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-primary alert_debit" role="alert">
                                Showing all records.
                            </div>
                            <table class="table table-hover table-striped table_debit_report">
                                <thead>
                                    <tr>
                                        <th>Debit/Consignment</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            let city_date = {
                date_from: null,
                date_to: null
            }

            let barangay_date = {
                date_from: null,
                date_to: null
            }
            
            let customer_date = {
                date_from: null,
                date_to: null
            }

            let debit_date = {
                date_from: null,
                date_to: null
            }
            
            
            // CITY
                let city_datatable = $('.table_city_report').DataTable({
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'csv',
                            filename: 'Lins Saver Patrol Report - City',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }, {
                            extend: 'pdf',
                            filename: 'Lins Saver Patrol Report - City',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }
                    ],
                    responsive: true,
                    autoWidth: false,
                    processing: true,
                    ajax: {
                        url: `${window.location.origin}/LinsSaverPatrol_CIS/public/api/report/city`,
                        method: "GET",
                        data: function ( d ) {
                            return $.extend( {}, d, city_date );
                        },
                        dataSrc: function (json) {
                            var return_data = new Array();
                            for(var i=0;i< json.length; i++){
                                return_data.push({
                                    "province" : json[i].province.description,
                                    "city" : json[i].city.description,
                                    "amount" : json[i].total_amount,
                                });
                            }
                            return return_data;
                        },
                    },
                    aoColumns: [
                        {"mData": "province"},
                        {"mData": "city"},
                        {"mData": "amount"},
                    ],
                });
            
            // BARANGAY
                let barangay_datatable = $('.table_barangay_report').DataTable({
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'csv',
                            filename: 'Lins Saver Patrol Report - Barangay',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }, {
                            extend: 'pdf',
                            filename: 'Lins Saver Patrol Report - Barangay',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }
                    ],
                    responsive: true,
                    autoWidth: false,
                    processing: true,
                    ajax: {
                        url: `${window.location.origin}/LinsSaverPatrol_CIS/public/api/report/barangay`,
                        method: "GET",
                        data: function ( d ) {
                            return $.extend( {}, d, barangay_date );
                        },
                        dataSrc: function (json) {
                            var return_data = new Array();
                            for(var i=0;i< json.length; i++){
                                return_data.push({
                                    "province" : json[i].province.description,
                                    "city" : json[i].city.description,
                                    "barangay" : json[i].barangay.description,
                                    "amount" : json[i].total_amount,
                                });
                            }
                            return return_data;
                        },
                    },
                    aoColumns: [
                        {"mData": "province"},
                        {"mData": "city"},
                        {"mData": "barangay"},
                        {"mData": "amount"},
                    ],
                });
            
            // CUSTOMER
                let customer_datatable = $('.table_agent_report').DataTable({
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'csv',
                            filename: 'Lins Saver Patrol Report - Agent',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }, {
                            extend: 'pdf',
                            filename: 'Lins Saver Patrol Report - Agent',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }
                    ],
                    responsive: true,
                    autoWidth: false,
                    processing: true,
                    ajax: {
                        url: `${window.location.origin}/LinsSaverPatrol_CIS/public/api/report/customer`,
                        method: "GET",
                        data: function ( d ) {
                            return $.extend( {}, d, customer_date );
                        },
                        dataSrc: function (json) {
                            var return_data = new Array();
                            for(var i=0;i< json.length; i++){
                                return_data.push({
                                    "customer" : `${json[i].customer.firstname} ${json[i].customer.middlename} ${json[i].customer.lastname}`,
                                    "amount" : json[i].total_amount,
                                });
                            }
                            return return_data;
                        },
                    },
                    aoColumns: [
                        {"mData": "customer"},
                        {"mData": "amount"},
                    ],
                });
                
            // DEBIT 
                let debit_datatable = $('.table_debit_report').DataTable({
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'csv',
                            filename: 'Lins Saver Patrol Report - Debit Amount Consignment',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }, {
                            extend: 'pdf',
                            filename: 'Lins Saver Patrol Report - Debit Amount Consignment',
                            className: 'btn btn-primary',
                            init: function(api, node, config) {
                                $(node).removeClass('btn-secondary')
                            }
                        }
                    ],
                    responsive: true,
                    autoWidth: false,
                    processing: true,
                    ajax: {
                        url: `${window.location.origin}/LinsSaverPatrol_CIS/public/api/report/debit`,
                        method: "GET",
                        data: function ( d ) {
                            return $.extend( {}, d, debit_date );
                        },
                        dataSrc: function (json) {
                            var return_data = new Array();
                            for(var i=0;i< json.length; i++){
                                return_data.push({
                                    "debit" : json[i].debit_amount,
                                    "amount" : json[i].total_amount,
                                });
                            }
                            return return_data;
                        },
                    },
                    aoColumns: [
                        {"mData": "debit"},
                        {"mData": "amount"},
                    ],
                });


            // CITY DATE RANGE
                $('#daterange_city').daterangepicker({
                    locale: {
                        format: 'Y-MM-DD'
                    }
                }, function(start, end, label) {
                    city_date.date_from = start.format('Y-MM-DD');
                    city_date.date_to = end.format('Y-MM-DD');
                    city_datatable.ajax.reload();
                    $('.alert_city').html(`Showing results from ${start.format('MMM DD, Y')} to ${end.format('MMM DD, Y')}`)
                });
                $('#daterange_city').on('apply.daterangepicker', function(ev, picker) {
                    city_date.date_from = picker.startDate.format('Y-MM-DD');
                    city_date.date_to = picker.endDate.format('Y-MM-DD');
                    city_datatable.ajax.reload();
                    $('.alert_city').html(`Showing results from ${picker.startDate.format('MMM DD, Y')} to ${picker.endDate.format('MMM DD, Y')}`)
                });


                $('.btn_show_city').on('click', function(){
                    city_date.date_from = null;
                    city_date.date_to = null;
                    city_datatable.ajax.reload();
                    $('.alert_city').html(`Showing all records`)
                });

            // BARANGAY DATE RANGE
                $('#daterange_barangay').daterangepicker({
                    locale: {
                        format: 'Y-MM-DD'
                    }
                }, function(start, end, label) {
                    barangay_date.date_from = start.format('Y-MM-DD');
                    barangay_date.date_to = end.format('Y-MM-DD');
                    barangay_datatable.ajax.reload();
                    $('.alert_barangay').html(`Showing results from ${start.format('MMM DD, Y')} to ${end.format('MMM DD, Y')}`)
                });
                $('#daterange_barangay').on('apply.daterangepicker', function(ev, picker) {
                    barangay_date.date_from = picker.startDate.format('Y-MM-DD');
                    barangay_date.date_to = picker.endDate.format('Y-MM-DD');
                    barangay_datatable.ajax.reload();
                    $('.alert_barangay').html(`Showing results from ${picker.startDate.format('MMM DD, Y')} to ${picker.endDate.format('MMM DD, Y')}`)

                });
                $('.btn_show_barangay').on('click', function(){
                    barangay_date.date_from = null;
                    barangay_date.date_to = null;
                    barangay_datatable.ajax.reload();
                    $('.alert_barangay').html(`Showing all records`)
                });

            // CUSTOMER DATE RANGE
                $('#daterange_customer').daterangepicker({
                    locale: {
                        format: 'Y-MM-DD'
                    }
                }, function(start, end, label) {
                    customer_date.date_from = start.format('Y-MM-DD');
                    customer_date.date_to = end.format('Y-MM-DD');
                    customer_datatable.ajax.reload();
                    $('.alert_customer').html(`Showing results from ${start.format('MMM DD, Y')} to ${end.format('MMM DD, Y')}`)
                });
                $('#daterange_customer').on('apply.daterangepicker', function(ev, picker) {
                    customer_date.date_from = picker.startDate.format('Y-MM-DD');
                    customer_date.date_to = picker.endDate.format('Y-MM-DD');
                    customer_datatable.ajax.reload();
                    $('.alert_customer').html(`Showing results from ${picker.startDate.format('MMM DD, Y')} to ${picker.endDate.format('MMM DD, Y')}`)
                });

                $('.btn_show_customer').on('click', function(){
                    customer_date.date_from = null;
                    customer_date.date_to = null;
                    customer_datatable.ajax.reload();
                    $('.alert_customer').html(`Showing all records`)
                });
            
            // DEBIT DATE RANGE
                $('#daterange_debit').daterangepicker({
                    locale: {
                        format: 'Y-MM-DD'
                    }
                }, function(start, end, label) {
                    debit_date.date_from = start.format('Y-MM-DD');
                    debit_date.date_to = end.format('Y-MM-DD');
                    debit_datatable.ajax.reload();
                    $('.alert_debit').html(`Showing results from ${start.format('MMM DD, Y')} to ${end.format('MMM DD, Y')}`)

                });
                $('#daterange_debit').on('apply.daterangepicker', function(ev, picker) {
                    debit_date.date_from = picker.startDate.format('Y-MM-DD');
                    debit_date.date_to = picker.endDate.format('Y-MM-DD');
                    debit_datatable.ajax.reload();
                    $('.alert_debit').html(`Showing results from ${picker.startDate.format('MMM DD, Y')} to ${picker.endDate.format('MMM DD, Y')}`)
                });
           
                $('.btn_show_debit').on('click', function(){
                    debit_date.date_from = null;
                    debit_date.date_to = null;
                    debit_datatable.ajax.reload();
                    $('.alert_debit').html(`Showing all records`)
                });
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/reports/index.blade.php ENDPATH**/ ?>