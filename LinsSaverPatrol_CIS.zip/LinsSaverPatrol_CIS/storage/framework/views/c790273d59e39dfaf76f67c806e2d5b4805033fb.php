<?php $__env->startSection('title','Item List'); ?>
<?php $__env->startSection('container'); ?>

    <div class="item_ist">
        <a href="<?php echo e(route('item_add')); ?>" class='btn btn-primary'>ADD NEW ITEM</a>
        <div class="table_container block_container">
            <table class="table table-hover" id="item_ist">
                <thead>
                    <tr>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Date Updated</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->code); ?></td>
                        <td><?php echo e($item->firstname); ?> <?php echo e($item->middlename); ?> <?php echo e($item->lastname); ?> </td>
                        <td><?php echo e($item->store_category->description); ?></td>
                        <td><?php echo e($item->address); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($item->status == 1 ? 'success' : 'danger'); ?>">
                                <?php echo e($item->status == 1 ? 'active' : 'inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('item_details', $item->id)); ?>" type="button" class='btn btn-primary'>View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            $('#item_ist').DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\linssaverpatrol_cis\resources\views/items/list.blade.php ENDPATH**/ ?>