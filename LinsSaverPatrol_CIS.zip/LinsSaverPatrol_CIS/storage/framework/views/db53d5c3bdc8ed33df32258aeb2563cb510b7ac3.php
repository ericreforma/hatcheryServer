<?php $fullname = 'Edit Customer - ' .$customer->firstname . ' ' . $customer->middlename . ' ' . $customer->lastname ?>
<?php $__env->startSection('title',$fullname); ?>
<?php $__env->startSection('container'); ?>

    <div class="customer_add block_container">

        <form class="form-inline" method=POST action="<?php echo e(route('customer_editstore')); ?>" accept-charset="UTF-8" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="container-fluid">
                <input value="<?php echo e($customer->id); ?>" type="hidden" class='form-control' name='id' id='id'>
                <div class="row">
                    <!-- PROFILE -->
                        <div class=" col-lg-6 col-md-12 col-sm-12">
                            <h2>Profile</h2>
                            <hr />
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="lastname">Last Name</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->lastname); ?>" type="text" class='form-control' name='lastname' id='lastname'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="firstname">First Name</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input  value="<?php echo e($customer->firstname); ?>"type="text" class='form-control' name='firstname' id='firstname'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="middlename">Middle Name</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->middlename); ?>" type="text" class='form-control' name='middlename' id='middlename'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Store Name</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->store_name); ?>" type="text" class='form-control' name='store_name' id='store_name'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Store Category</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <select class='form-control' name='store_category' id='store_category'>
                                            <option value='0'>- Select a Category -</option>
                                            <?php $__currentLoopData = $storeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storeCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($storeCategory->id); ?>" <?php echo e($customer->store_category_id == $storeCategory->id ? 'selected' : ''); ?>><?php echo e($storeCategory->description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Contact Number</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->contact_number); ?>" type="text" class='form-control' name='contact_number' id='contact_number'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Email</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->email); ?>" type="email" class='form-control' name='email' id='email'>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <!-- LOCATION -->

                        <div class=" col-lg-6 col-md-12 col-sm-12">
                            <h2>Location</h2>
                            <hr />
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Province</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <select class='form-control' name='province' id='province'>
                                            <option value='0'>- Select a Province -</option>
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value='<?php echo e($province->code); ?>' <?php echo e($customer->province_code == $province->code ? 'selected' : ''); ?>><?php echo e($province->description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">City / Municipality</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <select class='form-control' name='cities' id='cities'>
                                            <option value='<?php echo e($customer->city_code); ?>'><?php echo e($customer->city->description); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Barangay</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <select class='form-control' name='barangays' id='barangays'>
                                            <option value='<?php echo e($customer->barangay_code); ?>'><?php echo e($customer->barangay->description); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Complete Address</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->address); ?>" type="text" class='form-control' name='address' id='address'>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="customer_name">Land Mark</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <input value="<?php echo e($customer->landmark); ?>" type="text" class='form-control' name='landmark' id='landmark'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class=" col-md-4 col-sm-12">
                                        <label for="google_map">Google Map</label>
                                    </div>
                                    <div class=" col-md-8 col-sm-12">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <a href="https://www.google.com/maps" class="btn btn-secondary" type="button" id="google_map" target="_blank">Open Google Map</a>
                                            </div>
                                            <input type="text" class="form-control" 
                                            value="<?php echo e($customer->google_map); ?>"
                                            name="google_map"
                                            id="google_map"
                                            placeholder="" aria-label="Example text with button addon" aria-describedby="google_map">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            <!-- PHOTOS -->
                <div class="row">
                    <div class=" col-12">
                        <h2>Photos</h2>
                        <hr />
                        <div class="row">
                            <div class=" col-sm-12 col-md-12 col-lg-6">
                                <div class="form-group">
                                    <label for="idAttachment">Identification Card</label>
                                    <input type="file" class='form-control input-upload-image' name='idAttachment' id='idAttachment'>
                                    <label for="idAttachment" class='image_preview'>
                                        <span>Upload Photo</span>
                                        <img src="/LinsSaverPatrol_CIS/public/storage/media/<?php echo e($customer->idMedia->url); ?>" alt="preview" class='img_previewer idAttachment show_preview' >
                                    </label>
                                </div>
                            </div>
                            <div class=" col-sm-12 col-md-12 col-lg-6">
                                <div class="form-group">
                                    <label for="store_photo">Store Photo</label>
                                    <input type="file" class='form-control input-upload-image' name='store_photo' id='store_photo'>
                                    <label for="store_photo" class='image_preview '>
                                        <span>Upload Photo</span>
                                        <img src="/LinsSaverPatrol_CIS/public/storage/media/<?php echo e($customer->storeMedia->url); ?>" alt="preview" class='img_previewer store_photo show_preview'>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- SUBMIT BUTTON -->

                <div class="row justify-content-center">
                    <div class=" col-md-3 col-sm-12">
                        <button type="submit" class="btn btn-success btn-block">
                            SAVE
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/customers/edit.blade.php ENDPATH**/ ?>