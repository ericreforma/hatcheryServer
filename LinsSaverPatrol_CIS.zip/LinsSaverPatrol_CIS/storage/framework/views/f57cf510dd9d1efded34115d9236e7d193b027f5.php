<div class="navigation">
    <ul class="main-menu">
        <?php $__currentLoopData = Auth::user()->privileges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($priv->feature_id == 1 && $priv->role_view == 1): ?>
                <li class="<?php echo e(session('active_nav') == 'customer' ? 'active' : ''); ?>"><a href="<?php echo e(route('customer_list')); ?>"><i class="fas fa-store"></i><span>Customers</span></a></li>
            <?php endif; ?>

            <?php if($priv->feature_id == 2 && $priv->role_view == 1): ?>
                <li class="<?php echo e(session('active_nav') == 'items' ? 'active' : ''); ?>"><a href="<?php echo e(route('item_list')); ?>"><i class="fas fa-box-open"></i><span>Items</span></a></li>
            <?php endif; ?>

            <?php if($priv->feature_id == 3 && $priv->role_view == 1): ?>
                <li class="<?php echo e(session('active_nav') == 'reports' ? 'active' : ''); ?>"><a href="<?php echo e(route('report_view')); ?>"><i class="fas fa-clipboard-list"></i><span>Reports</span></a></li>
            <?php endif; ?>

            <?php if($priv->feature_id == 4 && $priv->role_view == 1): ?>
                <li class="<?php echo e(session('active_nav') == 'users' ? 'active' : ''); ?>"><a href="<?php echo e(route('users_list')); ?>"><i class="far fa-address-book"></i><span>User Management</span></a></li>
            <?php endif; ?>

            <?php if($priv->feature_id == 6 && $priv->role_view == 1): ?>
                <li class="<?php echo e(session('active_nav') == 'store_category' ? 'active' : ''); ?>"><a href="<?php echo e(route('storeCategory_view')); ?>"><i class="fas fa-store-alt"></i><span>Store Categories</span></a></li>
            <?php endif; ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <li class="<?php echo e(session('active_nav') == 'geo' ? 'active' : ''); ?>"><a href=""><i class="fas fa-globe-asia"></i><span>Geo Data</span></a></li> -->
    </ul>
</div>
<div class="menu_cover"></div><?php /**PATH D:\xampp\htdocs\influencer\LinsSaverPatrol_CIS\resources\views/master/navigation.blade.php ENDPATH**/ ?>