<table class="author_table">
    <tr>
        <td>Created By:</td>
        <td>
            
            <?php echo e($creator->user->firstname); ?>

            <?php echo e($creator->user->middlename); ?>

            <?php echo e($creator->user->lastname); ?>

        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php echo e(date_format($creator->created_at, 'M d, Y h:i:s A')); ?>

        </td>
    </tr>
    <?php if($editor !== null): ?>
    <tr>
        <td>Last update by:</td>
        <td>
            <?php echo e($editor->user->firstname); ?>

            <?php echo e($editor->user->middlename); ?>

            <?php echo e($editor->user->lastname); ?>

        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php echo e(date_format($editor->created_at, 'M d, Y h:i:s A')); ?>

        </td>
    </tr>
    <?php endif; ?>
</table><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/components/author.blade.php ENDPATH**/ ?>