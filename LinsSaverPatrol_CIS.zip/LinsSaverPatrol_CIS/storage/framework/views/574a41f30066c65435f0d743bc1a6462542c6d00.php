<?php $__env->startSection('title','Customer List'); ?>
<?php $__env->startSection('container'); ?>

    <div class="customer_list">
        <a href="<?php echo e(route('customer_add')); ?>" class='btn btn-primary'>ADD NEW CUSTOMER</a>
        <div class="table_container block_container">
            <table class="table table-hover" id="customer_list">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Store Category</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->code); ?></td>
                        <td><?php echo e($customer->firstname); ?> <?php echo e($customer->middlename); ?> <?php echo e($customer->lastname); ?> </td>
                        <td><?php echo e($customer->store_category->description); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($customer->status == 1 ? 'success' : 'danger'); ?>">
                                <?php echo e($customer->status == 1 ? 'active' : 'inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('customer_details', $customer->id)); ?>" type="button" class='btn btn-primary'>View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            $('#customer_list').DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\linssaverpatrol_cis\resources\views/customers/list.blade.php ENDPATH**/ ?>