<?php $__env->startSection('title','Item List'); ?>
<?php $__env->startSection('container'); ?>

    <div class="item_ist">
        <?php if(Auth::user()->item_role->role_add == 1): ?>
            <a href="<?php echo e(route('item_add')); ?>" class='btn btn-primary'>ADD NEW ITEM</a>
        <?php endif; ?>
        <div class="table_container block_container">
            <table class="table table-hover" id="item_list">
                <thead>
                    <tr>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->brand); ?></td>
                        <td><?php echo e($item->category); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->price->price); ?> / <?php echo e($item->unit->short_name); ?></td>

                        <td>
                            <a href="<?php echo e(route('item_details', $item->id)); ?>" type="button" class='btn btn-primary'>View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            $('#item_list').DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\influencer\LinsSaverPatrol_CIS\resources\views/items/list.blade.php ENDPATH**/ ?>