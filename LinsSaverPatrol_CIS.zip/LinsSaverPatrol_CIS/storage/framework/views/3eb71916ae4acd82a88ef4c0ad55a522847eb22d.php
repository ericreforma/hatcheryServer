<?php $__env->startSection('body'); ?>
    <div class="main_content">
        <div>
            <div>
                <h1><?php echo $__env->yieldContent('title'); ?></h1>
                <?php echo $__env->yieldContent('container'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\linssaverpatrol_cis\resources\views/master/body.blade.php ENDPATH**/ ?>