<?php $__env->startSection('title',  $item->name); ?>
<?php $__env->startSection('container'); ?>

    <div class="item_details container-fluid block_container">
            
            <div class="row">
                <div class=" col-sm-12 col-md-12 col-lg-12">
                    <table class='table_details'>
                        <tr>
                            <td>BRAND</td>
                            <td><?php echo e($item->brand); ?></td>
                        </tr>
                        <tr>
                            <td>CATEGORY</td>
                            <td><?php echo e($item->category); ?> </td>
                        </tr>
                        <tr>
                            <td>NAME</td>
                            <td><?php echo e($item->name); ?> </td>
                        </tr>
                        <tr>
                            <td>PRICE</td>
                            <td><?php echo e($item->price->price); ?>  / <?php echo e($item->unit->short_name); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <hr>
            <div class="row justify-content-end">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <?php $__env->startComponent('components.author',['creator' => $creator, 'editor' => $editor]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
            <div class="row justify-content-end">
                <div class=" col-sm-4 col-md-3 col-lg-2">
                    <a href="<?php echo e(route('item_editview',$item->id)); ?>" type="button" class="btn btn-primary btn-block">EDIT</a>
                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/items/details.blade.php ENDPATH**/ ?>