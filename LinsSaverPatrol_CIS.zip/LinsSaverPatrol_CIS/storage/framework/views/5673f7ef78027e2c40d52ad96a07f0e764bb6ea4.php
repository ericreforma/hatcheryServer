<div class="navigation">
    
    <ul class="main-menu">

        <li class="<?php echo e(session('active_nav') == 'customer' ? 'active' : ''); ?>"><a href="<?php echo e(route('customer_list')); ?>"><i class="fas fa-store"></i><span>Customers</span></a></li>
        <li class="<?php echo e(session('active_nav') == 'items' ? 'active' : ''); ?>"><a href="<?php echo e(route('item_list')); ?>"><i class="fas fa-box-open"></i><span>Items</span></a></li>
        <!-- <li class="<?php echo e(session('active_nav') == 'store_category' ? 'active' : ''); ?>"><a href=""><i class="fas fa-store-alt"></i><span>Store Categories</span></a></li> -->
        <!-- <li class="<?php echo e(session('active_nav') == 'geo' ? 'active' : ''); ?>"><a href=""><i class="fas fa-globe-asia"></i><span>Geo Data</span></a></li> -->
        <li class="<?php echo e(session('active_nav') == 'reports' ? 'active' : ''); ?>"><a href="<?php echo e(route('report_view')); ?>"><i class="fas fa-clipboard-list"></i><span>Reports</span></a></li>
        <!-- <li class="<?php echo e(session('active_nav') == 'user_access' ? 'active' : ''); ?>"><a href=""><i class="far fa-address-book"></i><span>User Access</span></a></li> -->

    </ul>

</div>
<div class="menu_cover"></div><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/master/navigation.blade.php ENDPATH**/ ?>