<?php $__env->startSection('title','User List'); ?>
<?php $__env->startSection('container'); ?>

    <div class="user_list">
        <a href="<?php echo e(route('users_add')); ?>" class='btn btn-primary'>ADD NEW USER</a>
        <div class="table_container block_container">
            <table class="table table-hover" id="user_list_table">
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Type</th>
                        <th>Member since</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($user->media_id == 0): ?>
                                <div class="letter_profile_picture">
                                    <span>
                                        <?php echo e(substr($user->username, 0, 1)); ?>

                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="letter_profile_picture profile_picture" style="background-image: url('/influencer/LinsSaverPatrol_CIS/public/storage/media/<?php echo e($user->media->url); ?>')">
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($user->firstname); ?> <?php echo e($user->middlename); ?> <?php echo e($user->lastname); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td>
                            <h5>

                            <span class="badge badge-<?php echo e($user->type_id == 1 ? 'primary' : 'warning'); ?>">
                                <?php echo e($user->type->description); ?>

                            </span>

                            </h5>

                        </td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('M d, Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('users_details', ['id' => $user->id])); ?>" class="btn btn-primary">
                                VIEW
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            $('#user_list_table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\influencer\LinsSaverPatrol_CIS\resources\views/user/list.blade.php ENDPATH**/ ?>