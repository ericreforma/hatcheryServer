<?php $__env->startSection('title','Customer List'); ?>
<?php $__env->startSection('container'); ?>

    <div class="customer_list">
        <div class="row justify-content-between">
            <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <a href="<?php echo e(route('customer_add')); ?>" class='btn btn-primary btn-block'>ADD NEW CUSTOMER</a>

            </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <button class="btn btn-light btn-block btn_filter" type="button" data-toggle="collapse" data-target="#filterCollapse" aria-expanded="false" aria-controls="filterCollapse">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
           
        </div>
            
        <div class="collapse" id="filterCollapse"> 
            <div class='block_container filter_container' >
                <h5><i class="fas fa-filter"></i> Filter</h5>
                <div class="row filter_select" >
                    <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                        <h6>Province</h6>
                        <select required class='form-control' name='province' id='province'>
                            <option value=''>- Select a Province -</option>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($province->code); ?>'><?php echo e($province->description); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                        <h6>City / Municipality</h6>
                        <select required class='form-control' name='cities' id='cities'>
                        </select>
                    </div>
                    <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                        <h6>Barangay</h6>
                        <select required class='form-control' name='barangays' id='barangays'>
                        </select>
                    </div>
                </div>
                <div class="row justify-content-end filter_buttons">
                    <div class="col-12 col-sm-3 col-md-2 col-lg-2">
                        <div class="btn btn-success btn-block search_filtered">SEARCH</div>
                    </div>
                    <div class="col-12 col-sm-3 col-md-2 col-lg-2">
                        <div class="btn btn-secondary btn-block clear_filtered">CLEAR</div>
                    </div>
                    <div class="col-12 col-sm-3 col-md-2 col-lg-2">
                        <div class="btn btn-dark btn-block close_filtered">CLOSE</div>
                    </div>
                </div>
              
            </div>
        </div>

        <div class="collapse" id="filterResultCollapse"> 
            <div class='block_container filter_container' >
                <h5>Showing results for <span> </span></h5>
                <button class="btn btn-primary clear_filtered">CLEAR FILTER</button>
            </div>        
        </div>

        <div class="table_container block_container">
            <table class="table table-hover" id="customer_list">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Store Category</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                   
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function(){
            let filtered = 0;
            let myData = {
                filtered: filtered,
            };

            let customer_datatable = $('#customer_list').DataTable({
                responsive: true,
                autoWidth: false,
                processing: true,
                ajax: {
                    url: `${window.location.origin}/influencer/LinsSaverPatrol_CIS/public/api/customer/list`,
                    data: function ( d ) {
                        return $.extend( {}, d, myData );
                    },
                    method: "GET",
                    dataSrc: function (json) {
                        var return_data = new Array();
                        for(var i=0;i< json.length; i++){
                            return_data.push({
                            "code" : json[i].code,
                            "name" : `${json[i].firstname} ${json[i].middlename} ${json[i].lastname}`,
                            "store_category" : json[i].store_category.description,
                            "address" : json[i].address,
                            "status" : `
                                <span class="badge badge-${json[i].status == 1 ? 'success' : 'danger' }">
                                    ${json[i].status == 1 ? 'active' : 'inactive' }
                                </span>
                            `,
                            "menu" : `
                                <a href="${window.location.origin}/influencer/LinsSaverPatrol_CIS/public/customer/details/${json[i].id}" type="button" class='btn btn-secondary'>View</a>
                            `
                            });
                        }
                        return return_data;
                    },
                },
                aoColumns: [
                    {"mData": "code"},
                    {"mData": "name"},
                    {"mData": "store_category"},
                    {"mData": "address"},
                    {"mData": "status"},
                    {"mData": "menu"},
                ],
            });

            
            $('.search_filtered').on('click', function(){
                $('#filterResultCollapse').collapse('show');
                let message = `${$('#province').val() == '' || $('#province').val() == null ? '' : '"' + $('#province option:selected').html() + '"'} `;
                    message += `${$('#cities').val() == '' || $('#cities').val() == null ? '' : '"' + $('#cities option:selected').html() + '"'}  `;
                    message += `${$('#barangays').val() == '' || $('#barangays').val() == null ? '' : '"' + $('#barangays option:selected').html() + '"'} `;
                
                $('#filterResultCollapse h5 span').html(message);
                myData = {
                    filtered: 1,
                    province: $('#province').val(),
                    city: $('#cities').val(),
                    barangay: $('#barangays').val()
                };
                customer_datatable.ajax.reload();
            });

            $('.close_filtered').on('click', function(){
                $('#filterCollapse').collapse('hide');
            });

            $('.clear_filtered').on('click', function(){
                $('#filterResultCollapse').collapse('hide');
                $('#province').val('').change();
                $('#cities').val('').change();

                myData = {
                    filtered: 0,
                };
                customer_datatable.ajax.reload();
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LinsSaverPatrol_CIS\resources\views/customers/list.blade.php ENDPATH**/ ?>