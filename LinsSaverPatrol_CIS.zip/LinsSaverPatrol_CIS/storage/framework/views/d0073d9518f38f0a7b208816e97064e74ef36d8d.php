<?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldContent('modal'); ?>
    <?php echo $__env->make('master.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('master.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\influencer\LinsSaverPatrol_CIS\resources\views/master/layout.blade.php ENDPATH**/ ?>