<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemFeatures extends Model
{
    protected $table = 'system_features';
    
}
